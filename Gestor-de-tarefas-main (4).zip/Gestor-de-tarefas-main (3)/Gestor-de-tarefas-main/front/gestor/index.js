
const API_URL = '/api/tarefa';

// Quando a tela carregar, chama a lista
document.addEventListener('DOMContentLoaded', carregarTarefas);

// 1. FUNÇÃO PARA CRIAR (O seu POST)
document.getElementById('formTarefa').addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const dados = {
        titulo: document.getElementById('titulo').value,
        categoriaId: Number(document.getElementById('categoriaId').value),
        usuarioId: Number(document.getElementById('usuarioId').value),
        status: "Pendente" // Garante que nasce pendente
    };

    try {
        const response = await fetch(`${API_URL}/cadastrar`, {
            method: 'POST',
            headers: {'Content-Type': 'application/json'},
            body: JSON.stringify(dados)
        });

        if(response.ok) {
            alert('Tarefa criada!');
            document.getElementById('formTarefa').reset(); // Limpa os campos
            carregarTarefas(); // Atualiza a lista na hora
        } else {
            alert('Erro: Verifique se os IDs existem.');
        }
    } catch (error) {
        console.error('Erro:', error);
    }
});

// 2. FUNÇÃO PARA LISTAR (O GET)
async function carregarTarefas() {
    const lista = document.getElementById('listaTarefas');
    lista.innerHTML = '<p style="text-align:center">Carregando...</p>';

    try {
        const response = await fetch(`${API_URL}/listar`);
        const tarefas = await response.json();
        
        lista.innerHTML = '';

        if (tarefas.length === 0) {
            lista.innerHTML = '<p style="text-align:center">Nenhuma tarefa ainda.</p>';
            return;
        }

        tarefas.forEach(t => {
            const div = document.createElement('div');
            // Se status for Concluída, adiciona classe especial
            div.className = `task-card ${t.status === 'Concluída' ? 'concluida' : ''}`;
            
            div.innerHTML = `
                <div class="info">
                    <strong>${t.titulo}</strong>
                    <small>${t.status}</small>
                </div>
                <div class="btn-group">
                    ${t.status !== 'Concluída' ? 
                        `<button onclick="concluirTarefa(${t.id})" class="btn-check" title="Concluir">✔</button>` : ''}
                    <button onclick="deletarTarefa(${t.id})" class="btn-trash" title="Apagar">🗑️</button>
                </div>
            `;
            lista.appendChild(div);
        });
    } catch (error) {
        lista.innerHTML = '<p>Erro ao conectar com o servidor.</p>';
    }
}

// 3. FUNÇÃO PARA CONCLUIR (O PUT)
async function concluirTarefa(id) {
    await fetch(`${API_URL}/${id}`, { method: 'PUT' });
    carregarTarefas();
}

// 4. FUNÇÃO PARA DELETAR (O DELETE)
async function deletarTarefa(id) {
    if(confirm('Quer mesmo apagar essa tarefa?')) {
        await fetch(`${API_URL}/${id}`, { method: 'DELETE' });
        carregarTarefas();
    }
}